package upt.ac.cti.sut.aperture.test4;

public class B {

}

class B1 extends B {
	
}

class B2 extends B {
	
}