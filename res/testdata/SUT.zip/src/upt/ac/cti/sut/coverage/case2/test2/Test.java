package upt.ac.cti.sut.coverage.case2.test2;

public class Test {
	
	private A a;
	private B b;
	
	public Test() {
		A x = new A1();;
		B y;
		y = true ? new B1() : new B2();
		this.a = x;
		this.b = y;
		
	}

	
}

