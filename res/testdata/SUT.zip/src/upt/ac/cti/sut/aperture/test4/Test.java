package upt.ac.cti.sut.aperture.test4;

public class Test {
	
	private A a;
	private B b;
	private A[] c;

}

