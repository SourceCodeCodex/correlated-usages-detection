package upt.ac.cti.sut.aperture.test6;

public abstract class B {

}

class B1 extends B {
	
}

class B2 extends B {
	
}