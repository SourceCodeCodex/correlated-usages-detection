package upt.ac.cti.sut.aperture.test6;


public abstract class A {

}

class A1 extends A {
	
}

class A2 extends A {
	
}
