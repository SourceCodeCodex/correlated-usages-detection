package upt.ac.cti.sut.aperture.test8;

import java.util.logging.Logger;

public class Test {
	
	private A a;
	private B b;
	private Logger logger;
	

}

