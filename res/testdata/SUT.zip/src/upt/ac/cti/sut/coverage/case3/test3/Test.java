package upt.ac.cti.sut.coverage.case3.test3;

public class Test {
	
	private A a;
	private B b;
	
	public Test() {
		this.a = Factory.newA1();
		this.b = Factory.newB1();
		
	}
	
	public Test(int k) {
		this.a = Factory.newA2();
		this.b = Factory.newB2();
		
	}
	
}

class Factory {
	
	public static A1 newA1() {
		return new A1();
	}
	
	public static B1 newB1() {
		return new B1();
	}
	
	public static A2 newA2() {
		return new A2();
	}
	
	public static B2 newB2() {
		return new B2();
	}
	
}
