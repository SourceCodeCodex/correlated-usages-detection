package upt.ac.cti.sut.aperture.test7;

public class C {

}
