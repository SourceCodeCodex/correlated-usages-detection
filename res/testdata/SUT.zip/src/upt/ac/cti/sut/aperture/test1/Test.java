package upt.ac.cti.sut.aperture.test1;

public class Test {
	
	private A a;
	private B b;

}

