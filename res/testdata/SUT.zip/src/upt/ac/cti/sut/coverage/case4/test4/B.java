package upt.ac.cti.sut.coverage.case4.test4;

public class B {

}

class B1 extends B {
	
}

class B2 extends B {
	
}