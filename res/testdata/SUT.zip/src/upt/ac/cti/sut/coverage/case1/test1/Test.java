package upt.ac.cti.sut.coverage.case1.test1;

public class Test {
	
	private A a;
	private B b;
	
	public Test() {
		this.a = new A1();
		this.b = new B1();
		
	}

}

