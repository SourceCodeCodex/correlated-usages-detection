package upt.ac.cti.sut.aperturecoverage.test1;

public class Test {

	private A a;
	private B b;
	
	private Test inner = new Test();

	public Test() {

	}
	
	public void setA(A a) {
		this.a = a;
		inner.a = a;
	}
	
	public void setB(B b) {
		this.b = b;
		inner.b = b;
	}
	
}

class Client {
	
	public static void main(String[] argv) {
		var test1 = new Test();
		test1.setA(new A1());
		test1.setB(new B1());
		
	}
	
}

