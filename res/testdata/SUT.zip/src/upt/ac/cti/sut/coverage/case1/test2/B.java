package upt.ac.cti.sut.coverage.case1.test2;

public class B {

}

class B1 extends B {
	
}

class B2 extends B {
	
}