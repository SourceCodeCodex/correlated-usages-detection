package upt.ac.cti.sut.aperturecoverage.test3;


abstract class ATest {
	
	protected A a;
	protected B b;
	
}

public class Test extends ATest {

	private A a;
	private B b;

	public Test() {

	}
	
	public void setA(A a) {
		this.a = a;
	}
	
	public void setB(B b) {
		this.b = b;
	}
	
	public void setSuperA(A a) {
		super.a = a;
	}
	
	public void setSuperB(B b) {
		super.b = b;
	}
	
	public void swap() {
		var auxA = this.a;
		var auxB = this.b;
		this.a = super.a;
		this.b = super.b;
		super.a = auxA;
		super.b = auxB;
	}
	
	
}

class Client {
	public static void main() {
		
		var i1 = new Test();
		
		i1.setA(new A1());
		i1.setB(new B1());
		
		i1.setSuperA(new A());
		i1.setSuperB(new B());
		
	}
}

