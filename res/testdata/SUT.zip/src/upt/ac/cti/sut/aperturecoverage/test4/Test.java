package upt.ac.cti.sut.aperturecoverage.test4;

public class Test {

	private A a;
	private B b;
	
	private Test inner = new Test();

	public Test() {

	}
	
	public void setA(A a) {
		this.a = a;
	}
	
	public void setB(B b) {
		this.b = b;
	}
	
	public void setInnerA(A a) {
		this.a = a;
	}
	
	public void setInnerB(B b) {
		this.b = b;
	}
	
	public void swap() {
		var auxA = this.a;
		var auxB = this.b;
		this.a = inner.a;
		this.b = inner.b;
		inner.a = auxA;
		inner.b = auxB;
	}
	
}

class Client {
	
	public static void main(String[] argv) {
		var test1 = new Test();
		test1.setA(new A1());
		test1.setB(new B1());
		
		test1.setInnerA(new A2());
		test1.setInnerB(new B2());
		
	}
	
}

