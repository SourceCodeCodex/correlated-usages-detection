package upt.ac.cti.sut.aperture.test5;

import java.util.List;

public class Test {
	
	private A a;
	private B b;
	private List<A> c;

}

