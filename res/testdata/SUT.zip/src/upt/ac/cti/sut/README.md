# Tests documentation

### System under test (SUT) structure

Two metrics are tested:
* aperture
* aperture coverage 


### Aperture - *upt.ac.cti.sut.aperture*

This metric is not as problematic as **coverage**, thus all tests fall directly under the specified package. The tests validate whether the aperture is computed:
* **test1** - for simple reference fields
* **test2** - while ignoring *static* fields
* **test3** - while ignoring *primitive types*
* **test4** - while ignoring *arrays*
* **test5** - while ignoring *generic types*
* **test6** - while ignoring *abstract types*
* **test7** - while ignoring *types without hierarchy* (no descendants)
* **test8** - while ignoring *types outside source code*

### Coverage - *upt.ac.cti.sut.coverage*

There are a lot of use cases that should be treated separately in order to ensure the composability of the analysis. Fields can be written with:
* **case1** - instantiation
* **case2** - local variable
* **case3** - method invocation
* **case4** - parameter

### Aperture Coverage - *upt.ac.cti.sut.aperturecoverage*
The package contains more complex scenarios, with the attempt of covering all source code.
