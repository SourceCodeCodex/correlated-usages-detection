package upt.ac.cti.sut.coverage.case3.test2;

public class Test {
	
	private A a;
	private B b;
	
	public Test() {
		this.a = Factory.newA1();
		this.b = Factory.newB1();
		
	}
	
}

class Factory {
	
	public static A1 newA1() {
		return new A1();
	}
	
	public static B1 newB1() {
		return new B1();
	}
	
}
