package upt.ac.cti.sut.coverage.case2.test1;

public class Test {
	
	private A a;
	private A a2;

	
	public Test() {
		this.a2 = new A2();
		
		A x = new A();
		
		this.a = (x = new A1());
		
		this.a = this.a2;
		a2 = a;
		
	}

	
}

