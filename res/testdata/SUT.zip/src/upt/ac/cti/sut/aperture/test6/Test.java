package upt.ac.cti.sut.aperture.test6;

public class Test {
	
	private A a;
	private B b;

}

