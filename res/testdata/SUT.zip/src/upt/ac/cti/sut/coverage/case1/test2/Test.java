package upt.ac.cti.sut.coverage.case1.test2;

public class Test {
	
	private A a;
	private B b;
	
	public Test() {
		this.a = new A1();
		this.b = new B1();
		
	}
	
	public Test(int y) {
		this.a = new A2();
		this.b = new B2();
		
	}

}

