package upt.ac.cti.sut.coverage.case4.test3;

public class Test {
	
	private A a;
	private B b;
	
	public Test(A x, B y) {
		this.a = x;
		this.b = y;
		
	}
	
}

class Client {
	
	public static void main(String[] argv) {
		var m = new A();
		var n = new B();
		
		var test = new Test(m,n);
		
	}
	
}
