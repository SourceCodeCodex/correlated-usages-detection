package upt.ac.cti.sut.coverage.case4.test4;

public class Test {
	
	private A a;
	private B b;
	
	public Test(A x, B y) {
		this.a = x;
		this.b = y;
		
	}
	
}

class Client {
	
	public static void main(String[] argv) {
		var m = new A1();
		var n = new B1();
		
		var test = new Test(m,n);
		
	}
	
}

