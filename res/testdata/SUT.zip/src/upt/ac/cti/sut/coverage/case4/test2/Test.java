package upt.ac.cti.sut.coverage.case4.test2;

/**
 * Test passed.
 * Bad accuracy: expected 2, found 4;
 * 
 * @author alinrosu
 *
 */
public class Test {

	private A a;
	private B b;

	public Test(A1 a1,  B1 b1) {
		this.a = a1;
		this.b = b1;

	}
	
	public Test(A2 a2,  B2 b2) {
		this.a = a2;
		this.b = b2;

	}
}
