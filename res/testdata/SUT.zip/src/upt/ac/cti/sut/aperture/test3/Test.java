package upt.ac.cti.sut.aperture.test3;

public class Test {
	
	private A a;
	private B b;
	private int c;

}

