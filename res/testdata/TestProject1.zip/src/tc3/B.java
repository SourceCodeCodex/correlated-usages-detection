package tc3;

public interface B {

}
