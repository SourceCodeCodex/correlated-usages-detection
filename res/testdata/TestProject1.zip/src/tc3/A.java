package tc3;

public abstract class A {

}
