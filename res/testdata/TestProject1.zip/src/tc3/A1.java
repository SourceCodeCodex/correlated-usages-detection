package tc3;

public class A1 extends A {

}
