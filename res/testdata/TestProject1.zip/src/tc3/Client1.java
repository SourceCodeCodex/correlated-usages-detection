package tc3;

public class Client1 {
	
	public ClassOne<A1,B1> test(ClassOne<A2,B2> x) {
		return null;
	}

}
