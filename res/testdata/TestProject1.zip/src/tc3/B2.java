package tc3;

public class B2 implements B {

}
