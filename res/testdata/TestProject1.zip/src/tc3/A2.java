package tc3;

public class A2 extends A {

}
