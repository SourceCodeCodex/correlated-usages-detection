package tc7;

public class B2 implements B {

}
