package tc7;

public class Client1 {
	
	//a can be a new ClassOne<A12,B1> or a new ClassOne<A,B1>. We do not known how it is instantiated 
	//and thus, we assume it can be any of them. Thus in this case, we must consider that the first argument
	//can be at runtime any concrete type from the cone of A (the upper bound of the parameter declared for 
	//that parameter).
	ClassOne<? super A12, B1> a;
	
	void test() {
		A x = a.get(); //for sure it is assignable only to an A 
		//(i.e., the declared bound of the parameter), and thus, at runtime, it can be A1, A2 or A3
	}

}
