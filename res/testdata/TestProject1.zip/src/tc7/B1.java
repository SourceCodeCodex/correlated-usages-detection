package tc7;

public class B1 implements B {

}
