package tc7;

public class ClassOne<T extends A, K extends B> {

	void add(T x) {}
	T get() {return null;}
	
}
