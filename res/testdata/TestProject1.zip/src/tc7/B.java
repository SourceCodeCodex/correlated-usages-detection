package tc7;

public interface B {

}
