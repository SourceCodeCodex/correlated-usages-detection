package tc7;

public abstract class A {

}
