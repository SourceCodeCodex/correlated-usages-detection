package tc7;

public class A3 extends A {

}
