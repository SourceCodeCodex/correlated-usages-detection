package tc7;

public class A2 extends A12 {

}
