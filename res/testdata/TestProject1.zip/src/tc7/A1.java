package tc7;

public class A1 extends A12 {

}
