package tc2;

public class ClassOne<T extends A, K extends B> {

}
