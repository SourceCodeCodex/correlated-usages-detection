package tc2;

public abstract class A {

}
