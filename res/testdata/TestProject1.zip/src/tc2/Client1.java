package tc2;

public class Client1 {
	
	ClassOne<A1,B1> a;
	ClassOne<A2,B2> b;
	ClassOne<A1,B2> c;

}
