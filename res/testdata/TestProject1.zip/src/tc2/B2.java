package tc2;

public class B2 extends B {

}
