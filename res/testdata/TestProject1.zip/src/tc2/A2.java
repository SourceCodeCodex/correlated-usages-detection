package tc2;

public class A2 extends A {

}
