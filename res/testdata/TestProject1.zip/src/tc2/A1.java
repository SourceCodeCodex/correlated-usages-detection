package tc2;

public class A1 extends A {

}
