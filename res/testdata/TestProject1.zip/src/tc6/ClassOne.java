package tc6;

public class ClassOne<T extends A, K extends B> {

	void add(T x) {}
	T get() {return null;}
	
}
