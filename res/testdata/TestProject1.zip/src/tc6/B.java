package tc6;

public interface B {

}
