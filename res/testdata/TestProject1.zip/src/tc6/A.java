package tc6;

public abstract class A {

}
