package tc6;

public class B1 implements B {

}
