package tc6;

public class A1 extends A12 {

}
