package tc6;

public class A3 extends A {

}
