package tc6;

public abstract class A12 extends A {

}
