package tc6;

public class Client1 {
	
	//a can be a new ClassOne<A1,B1>, a new ClassOne<A2,B1> or a new ClassOne<A12,B1> from a static point of view.
	//We do not known how it is instantiated and thus, we assume it can be any of them. Consequently, the first
	//arg can be a A1 or a A2 at runtime (any concrete type in the cone of type at the right of extends wildcard)
	ClassOne<? extends /*concrete cone of this*/ A12, B1> a;

	void test() {
		A12 x = a.get(); //for sure it is assignable to a A12 or to a supertype of A12 thus, at runtime, it can be A1 or A2
	}

}
