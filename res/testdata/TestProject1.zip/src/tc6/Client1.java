package tc6;

public class Client1 {
	
	//Because a can be a new ClassOne<A1,B1> , a new ClassOne<A1,B2> or a new ClassOne<A1,B> from a static point of view
	ClassOne<A1,? extends B> a;

}
