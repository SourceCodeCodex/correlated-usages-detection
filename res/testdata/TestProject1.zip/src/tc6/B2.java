package tc6;

public class B2 implements B {

}
