package tc5;

public class A1 extends A12 {

}
