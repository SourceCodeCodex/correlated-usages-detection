package tc5;

public class B1 implements B {

}
