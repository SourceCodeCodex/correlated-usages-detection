package tc5;

public interface B {

}
