package tc5;

public abstract class A {

}
