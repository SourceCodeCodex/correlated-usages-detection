package tc5;

public class A2 extends A12 {

}
