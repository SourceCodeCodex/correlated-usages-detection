package tc5;

public class B2 implements B {

}
