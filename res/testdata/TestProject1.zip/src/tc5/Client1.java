package tc5;

public class Client1 {
	
	ClassOne<A12,B1> a;

}
