package tc5;

public class Client1 {

	//Because a may contain at runtime for the first argument an A1 or an A2 (A12 is their common abstract supertype) 
	ClassOne<A12,B1> a;

}
