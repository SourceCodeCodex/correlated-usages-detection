package tc1;

public class A2 extends A {

}
