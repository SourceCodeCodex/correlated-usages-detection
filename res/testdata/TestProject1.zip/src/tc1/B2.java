package tc1;

public class B2 extends B {

}
