package tc1;

public class B1 extends B {

}
