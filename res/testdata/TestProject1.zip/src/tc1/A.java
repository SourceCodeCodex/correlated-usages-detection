package tc1;

public abstract class A {

}
