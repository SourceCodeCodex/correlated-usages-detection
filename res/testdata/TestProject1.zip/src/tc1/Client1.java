package tc1;

public class Client1 {
	
	ClassOne<A1,B1> a;
	ClassOne<A2,B2> b;

}
