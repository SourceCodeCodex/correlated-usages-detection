package tc1;

public class ClassOne<T extends A, K extends B> {

}
