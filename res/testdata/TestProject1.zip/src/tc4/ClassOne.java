package tc4;

public class ClassOne<T extends A, K extends B> {

}
