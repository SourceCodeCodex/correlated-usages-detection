package tc4;

public abstract class A {

}
