package tc4;

public interface B {

}
