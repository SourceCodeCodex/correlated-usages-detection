package tc4;

public class A2 extends A12 {

}
