package tc4;

public class A1 extends A12 {

}
