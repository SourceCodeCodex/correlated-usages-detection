package tc4;

public class B1 implements B {

}
