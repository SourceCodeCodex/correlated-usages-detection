package tc4;

public abstract class A12 extends A {

}
