package tc4;

public class B2 implements B {

}
