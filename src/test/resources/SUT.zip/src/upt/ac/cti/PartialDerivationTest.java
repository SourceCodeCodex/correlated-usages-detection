package upt.ac.cti;

import upt.ac.cti.hierarchy.*;

abstract class APartialDerivationTest {
	protected B b = new B21();
	
	protected B getB() {
		return new B();
	}
}

public class PartialDerivationTest extends APartialDerivationTest {
	
	private A a1;
	private B b;
	private A a2;
	
	public void m() {
		a1 = a2 = new A();
		b = super.getB();
	}
	
	public void m1() {
		a1 = a2 = new A1();
		b = getB();
	}
	
	public void m2() {
		a1 = a2 = new A2();
		b = new PartialDerivationTestProvider().b;
	}
	
	public void m11() {
		a1 = a2 = new A11();
		b = PartialDerivationTestProvider.bs;
	}
	
	public void m21() {
		a1 = a2 = new A21();
		b = super.b;
	}
	
	

	protected B getB() {
		return new B1();
	}
}

class PartialDerivationTestProvider {
	B b = new B2();
	static B bs = new B11();
}