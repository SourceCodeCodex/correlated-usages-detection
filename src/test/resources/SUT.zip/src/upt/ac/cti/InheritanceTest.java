package upt.ac.cti;

import upt.ac.cti.hierarchy.*;

public class InheritanceTest {
	
	protected void doAB(A a, B b) {
	}
}

class InheritanceTest1 extends InheritanceTest {
	
	protected void doA(A a) {
	}
	
	protected void doB(B b) {
	}
	
	protected void doAB(A a, B b) {
		super.doAB(a, b);
	}	
	
}


class InheritanceTestClient {
	public void m() {
		var t1 = new InheritanceTest();
		var t2 = new InheritanceTest1();
		
		t1.doAB(new A1(), new B1());
		t2.doAB(new A2(), new B2());
		
		t2.doA(new A11());
		t2.doB(new B11());
	
	}
}