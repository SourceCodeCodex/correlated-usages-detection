package upt.ac.cti.hierarchy;

public class C {

}