package upt.ac.cti;

import upt.ac.cti.hierarchy.*;

public class DowncastTest {
	
	private A1 a;
	private B1 b;
	
	public DowncastTest(A a, B b) {
		var a11 = (A11) a;
		var b11 = (B11) b;
		this.a = a11;
		this.b = b11;
	}
}

class DowncastTestClient {
	public static void m() {
		A11 a = new A11();
		B11 b = new B11();
		new DowncastTest(a, b);
	}
}
