package upt.ac.cti.sut.coverage.case4.test3;

public class Test {
	
	private A a;
	private B b;
	
	public Test(A x, B y) {
		this.a = x;
		this.b = y;
		
	}
	
}


// ERROR: Field
class Client {
	
	public static void main(String[] argv) {
		var m = new A();
		var n = new B();
		
		var test1 = new Test(new A(), new B());
		var test2 = new Test(new A1(),new B1());
		
		
	}
	
}
