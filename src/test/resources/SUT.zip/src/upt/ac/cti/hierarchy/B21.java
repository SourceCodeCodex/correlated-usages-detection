package upt.ac.cti.hierarchy;

public class B21 extends B1 {
	
}