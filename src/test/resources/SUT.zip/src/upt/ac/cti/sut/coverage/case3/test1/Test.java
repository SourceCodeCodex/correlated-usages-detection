package upt.ac.cti.sut.coverage.case3.test1;

public class Test {

	private A a;
	private B b;

	public Test() {
		A x = newA();
		B y = newB();
		this.a = x;
		this.b = y;

	}

	private A newA() {
		return new A1();

	}

	private B newB() {
		return new B1();

	}

}
