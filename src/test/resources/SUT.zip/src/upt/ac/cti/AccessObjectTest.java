package upt.ac.cti;

import upt.ac.cti.hierarchy.*;

public class AccessObjectTest {
	
	private A a;
	private B b;
	
	public void setA(A a) {
		this.a = a;
	}
	
	public void setB(B b) {
		this.b = b;
	}
}

class AccessObjectTestClient {
	public static void m() {
		var t = new AccessObjectTest();
		
		t.setA(new A());
		t.setB(new B());
			
		t = new AccessObjectTest();
		
		t.setA(new A1());
		t.setB(new B1());

		var t1 = new AccessObjectTest();
		
		t1.setA(new A2());
		t1.setB(new B2());
		
		
	}
}
