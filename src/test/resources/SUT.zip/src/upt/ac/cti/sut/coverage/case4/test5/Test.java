package upt.ac.cti.sut.coverage.case4.test5;

public class Test {
	
	private A a;
	private B b;
	
	public Test() {
		
	}
	
	public void setA(A x) {
		this.a = x;
	}
	
	public void setB(B y) {
		this.b = y;
	}
	
}

// ERROR: Field
class Client {
	
	public static void main(String[] argv) {
		
		var test = new Test();
		
		test.setA(new A());
		test.setB(new B());
		
		test = new Test();
		test.setA(new A1());
		test.setB(new B1());
		
		test = new Test();
		test.setA(new A1());
		
		test = new Test();
		test.setB(new B1());
	}
	
}

