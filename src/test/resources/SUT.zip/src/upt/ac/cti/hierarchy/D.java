package upt.ac.cti.hierarchy;

public class D {

}
