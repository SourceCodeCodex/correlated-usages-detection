package upt.ac.cti;

import java.util.ArrayList;
import java.util.List;

import upt.ac.cti.hierarchy.A;
import upt.ac.cti.hierarchy.A1;
import upt.ac.cti.hierarchy.A11;
import upt.ac.cti.hierarchy.B;
import upt.ac.cti.hierarchy.B1;
import upt.ac.cti.hierarchy.B11;

public class ListTest {
	
	private List<A> a;
	private List<B> b;
	
	public ListTest() {
		a = new ArrayList<>();
		b = new ArrayList<>();
	}
	
	public void add(A a, B b) {
		this.a.add(a);
		this.b.add(b);
	}
}

class ListTestClient {
	public static void m() {
		var t = new ListTest();
		
		var a11 = new A11();
		var b11 = new B11();
		
		t = new ListTest();
		
		var a1 = new A1();
		var b1 = new B1();
		
		t.add(a11, b11);
		t.add(a1, b1);
		
		
	}
}
