package upt.ac.cti.hierarchy;

public class A21 extends A {
	
}