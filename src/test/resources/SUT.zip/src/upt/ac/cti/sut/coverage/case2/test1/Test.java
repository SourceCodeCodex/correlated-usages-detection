package upt.ac.cti.sut.coverage.case2.test1;

public class Test {
	
	private A a, a2;
	private B b;

	
	public Test() {
		this.b = new B();
		this.a2 = new A2();
		
		A x = new A();
		
		this.a = (x = new A1());
		
		this.a = this.a2;
		
	}

	
}

