package upt.ac.cti.hierarchy;

public class A11 extends A1 {
	
}