package upt.ac.cti.hierarchy;

public class B {

}