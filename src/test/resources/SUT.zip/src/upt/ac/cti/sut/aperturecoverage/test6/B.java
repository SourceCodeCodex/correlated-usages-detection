package upt.ac.cti.sut.aperturecoverage.test6;

public class B {

}

class B1 extends B {
	
}

class B2 extends B {
	
}