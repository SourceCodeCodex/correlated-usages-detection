package upt.ac.cti;

import upt.ac.cti.hierarchy.*;

public class ExceedDepthTest {
	
	private A a = a1();
	private B b = new B();
	
	private static A a1() {
		return a2();
	}
	
	private static A1 a2() {
		return a3();
	}
	
	private static A1 a3() {
		return a4();
	}
	
	private static A1 a4() {
		return a5();
	}
	
	private static A1 a5() {
		return a6();
	}
	
	private static A11 a6() {
		return new A11();
	}
	

}
