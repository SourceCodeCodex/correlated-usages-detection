package upt.ac.cti;

import java.util.ArrayList;
import java.util.List;

import upt.ac.cti.hierarchy.A;
import upt.ac.cti.hierarchy.A1;
import upt.ac.cti.hierarchy.A11;
import upt.ac.cti.hierarchy.B;
import upt.ac.cti.hierarchy.B1;
import upt.ac.cti.hierarchy.B11;

public class ListTest2 {
	
	private List<A> a;
	private List<B> b;
	
	public ListTest2() {
		a = new ArrayList<>();
		b = new ArrayList<>();
	}
	
	public void add(A a, List<B> b) {
		this.a.add(a);
		this.b.addAll(b);
	}
}

class ListTest2Client {
	public static void m() {
		var t = new ListTest2();
		
		var a1 = new A1();
		var b1 = new B1();
		
		t.add(a1, List.of(b1));
		
		
	}
}
