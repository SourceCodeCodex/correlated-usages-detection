package upt.ac.cti.sut.coverage.case4.test1;


public class Test {

	private A a;
	private B b;

	public Test(A a,  B b) {
		this.a = a;
		this.b = b;

	}
	
}
