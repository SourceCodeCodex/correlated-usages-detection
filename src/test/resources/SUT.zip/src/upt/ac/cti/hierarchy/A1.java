package upt.ac.cti.hierarchy;

public class A1 extends A {
	
}