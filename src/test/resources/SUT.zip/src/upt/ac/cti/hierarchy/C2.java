package upt.ac.cti.hierarchy;

public class C2 extends C {
	
}