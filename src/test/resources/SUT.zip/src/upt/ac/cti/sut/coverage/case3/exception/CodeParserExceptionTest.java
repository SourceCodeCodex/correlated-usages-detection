package upt.ac.cti.sut.coverage.case3.exception;

import java.util.logging.Logger;

public class CodeParserExceptionTest {
	
	private A a;
	private B b;
	
	public CodeParserExceptionTest() throws InstantiationException, IllegalAccessException {
		this.a = Factory.newA1();
		this.b = Factory.newB1();
		
	}
	
}

class Factory {
	
	// ERROR: Field
	public static A newA1() throws InstantiationException, IllegalAccessException {
		return (A) (Object) Logger.getGlobal();
	}
	
	public static B newB1() {
		return new B1();
	}
	
}

