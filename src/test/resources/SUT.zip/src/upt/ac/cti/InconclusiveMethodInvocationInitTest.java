package upt.ac.cti;

import upt.ac.cti.hierarchy.A;
import upt.ac.cti.hierarchy.A1;
import upt.ac.cti.hierarchy.B;
import upt.ac.cti.hierarchy.B1;
import upt.ac.cti.hierarchy.C;

public class InconclusiveMethodInvocationInitTest {

	private A a = (A)((Object) this.getClass().getAnnotatedInterfaces());
	private B b = new B1();
	private C c = (C)((Object) this.getClass().getAnnotatedInterfaces());
	
}
