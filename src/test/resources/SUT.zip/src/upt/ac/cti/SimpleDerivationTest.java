package upt.ac.cti;

import upt.ac.cti.hierarchy.*;

public class SimpleDerivationTest {
	
	private static boolean condition;
	
	private A a;
	private B b;
	
	private static B bs = new B2();
	
	public void m() {
		a = condition ? new A1() : new A2();
		B ba;
		b = (ba = new B1());
		b = bs;
		
	}

}
