package upt.ac.cti;

import java.util.List;
import java.util.logging.Logger;

import upt.ac.cti.hierarchy.A;
import upt.ac.cti.hierarchy.B;
import upt.ac.cti.hierarchy.C;
import upt.ac.cti.hierarchy.D;

public class PairingValidationTest {
	private A af;
	private B bf;
	private List<C> cf;
	private D df;
	
	private static A ign1f;
	private int ign2f;
	private A[] ign3f;
	private Logger ign4f;
	
	public void m(A ap, B bp, D dp,  List<C> ign1p, char ign2p, C[] ign3p, String ign4p) {
		
	}


}
