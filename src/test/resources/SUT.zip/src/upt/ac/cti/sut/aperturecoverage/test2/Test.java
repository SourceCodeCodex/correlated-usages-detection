package upt.ac.cti.sut.aperturecoverage.test2;

//TODO: Something strange happens here!
abstract class ATest {
	
	protected A a;
	protected B b;
	
	public ATest() {
		this.a = new A1();
		this.b = new B1();
	}
	
	protected A newA() {
		return new A();
	}
	
	protected B newB() {
		return new B();
	}
	
}

public class Test extends ATest {

	private A a;
	private B b;

	public Test() {

	}
	
	public void setM() {
		var newA = super.newA();
		this.a = newA;
		this.b = super.newB();
	}
	
	public void setF() {
		var newA = super.a;
		this.a = newA;
		this.b = super.b;
	}
	
	@Override
	protected A newA() {
		return new A2();
	}
	
	@Override
	protected B newB() {
		return new B2();
	}
	
	
}

