package upt.ac.cti.hierarchy;

public class B11 extends B1 {
	
}