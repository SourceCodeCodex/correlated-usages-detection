package upt.ac.cti;

import upt.ac.cti.hierarchy.*;

abstract class APartialDerivationTest2 {
	protected A a;
	protected B b;
	
	protected void setB(B b) {
		a = new A();
		this.b = b;
	}

	
}

public class PartialDerivationTest2 extends APartialDerivationTest2 {
	
	private A a;
	private B b;
	private final static PartialDerivationTestProvider1Provider p = new PartialDerivationTestProvider1Provider();
	
	public PartialDerivationTest2(B1 b) {
		this.a = new A1();
		this.b = b;
	}
	
	public void m() {
		super.setB(new B());
	}
	
	public void mc() {
		new PartialDerivationTest2(new B1());
	}
	
	public void m2() {
		a = new A2();
		b = p.b;
	}
	

}

class PartialDerivationTestProvider1Provider {
	B b;
	private static B bs = new B11();
	
	public void m() {
		b = new B2();
		b = bs;
	}
	
	
	
}