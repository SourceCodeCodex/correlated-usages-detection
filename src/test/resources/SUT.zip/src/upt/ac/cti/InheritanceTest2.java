package upt.ac.cti;

import upt.ac.cti.hierarchy.*;

public class InheritanceTest2 {
	protected A a;
	protected B b;
	
	protected void setAB(A a, B b) {
		this.a = a;
		this.b = b;
	}
}

class InheritanceTest21 extends InheritanceTest2 {
	protected A a;
	protected B b;
	
	protected void setA(A a) {
		this.a = a;
		super.a = a;
	}
	
	protected void setB(B b) {
		this.b = b;
		super.b = b;
	}
	
	protected void setAB(A a, B b) {
		this.a = a;
		this.b = b;
		super.setAB(a, b);
	}	
	
}


class InheritanceTest2Client {
	public void m() {
		var t1 = new InheritanceTest2();
		var t2 = new InheritanceTest21();
		
		t1.setAB(new A1(), new B1());
		t2.setAB(new A2(), new B2());
		
		t2.setA(new A11());
		t2.setB(new B11());
	
	}
}