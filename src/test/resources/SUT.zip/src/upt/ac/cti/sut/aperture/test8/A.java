package upt.ac.cti.sut.aperture.test8;

public class A {

}

class A1 extends A {
	
}

class A2 extends A {
	
}
