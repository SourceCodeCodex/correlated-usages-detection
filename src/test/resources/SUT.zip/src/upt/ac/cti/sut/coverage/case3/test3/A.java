package upt.ac.cti.sut.coverage.case3.test3;


public class A {

}

class A1 extends A {
	
}

class A2 extends A {
	
}
