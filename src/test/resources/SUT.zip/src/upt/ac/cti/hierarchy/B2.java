package upt.ac.cti.hierarchy;

public class B2 extends B {
	
}