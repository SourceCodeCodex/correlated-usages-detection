package upt.ac.cti;

import upt.ac.cti.hierarchy.*;

public class ThisApertureCoverageTest {
	private A a;
	private B b;
	private ThisApertureCoverageTest t;
	
	public void m() { 
		var bs = new B[10];
		a = null;
		b = bs[3];
		t = this;
	}

}

class InconclusiveApertureCoverageTest1 extends ThisApertureCoverageTest{
	
}

class InconclusiveApertureCoverageTest2 extends ThisApertureCoverageTest {
	
}
