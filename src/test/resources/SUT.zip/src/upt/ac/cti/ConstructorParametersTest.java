package upt.ac.cti;

import upt.ac.cti.hierarchy.*;

public class ConstructorParametersTest {
	
	public ConstructorParametersTest(A1 a, B1 b) {
		
	}

}

class ConstructorParametersTestClient {
	
	public void m() {
		A1 a1, a2;
		B1 b1, b2;
		
		a1 = new A1();
		b1 = new B1();
		
		new ConstructorParametersTest(a1, b1);
		
		a2 = new A11();
		b2 = new B11();
		
		new ConstructorParametersTest(a1, b2);
		
		
	}
}