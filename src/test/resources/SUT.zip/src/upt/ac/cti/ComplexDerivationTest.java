package upt.ac.cti;

import upt.ac.cti.hierarchy.*;

public class ComplexDerivationTest {
	
	private A a;
	private B b ;
	
	public void mf() {
		a = ComplexDerivationTestProvider.newA1();
		b = ComplexDerivationTestProvider.otherB1;
	}
	
	public void fm() {
		a = ComplexDerivationTestProvider.otherA1;
		b = ComplexDerivationTestProvider.newB1();
	}
	
	public void mm() {
		a = ComplexDerivationTestProvider.newA1();
		b = ComplexDerivationTestProvider.newB1();
	}
	
	public void ff() {
		a = ComplexDerivationTestProvider.otherA1;
		b = ComplexDerivationTestProvider.otherB1;
	}
	
	public void pf(A a) {
		this.a = a;
		this.b = ComplexDerivationTestProvider.otherB2;
	}
	
	public void fp(B b) {
		this.a = ComplexDerivationTestProvider.otherA2;
		this.b = b;
	}
	
	public void pm(A a) {
		this.a = a;
		this.b = ComplexDerivationTestProvider.newB2();
	}
	
	public void mp(B b) {
		this.a = ComplexDerivationTestProvider.newA2();
		this.b = b;
	}
	
	

}

class ComplexDerivationTestProvider {
	public static A otherA1 = new A1();
	public static B otherB1 = new B1();
	
	public static A otherA2 = new A2();
	public static B otherB2 = new B2();
	
	
	public static A1 newA1() {
		return new A1();
	}
	
	public static B1 newB1() {
		return new B1();
	}
	
	public static A2 newA2() {
		return new A2();
	}
	
	public static B2 newB2() {
		return new B2();
	}
}

class ComplexDerivationTestClient {
	public static void m() {
		var t = new ComplexDerivationTest();
		
		t.pf(new A2());
		t.fp(new B2());
		
		t.pm(new A11());
		t.mp(new B11());
	}
	
}
