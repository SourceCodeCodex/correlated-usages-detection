package upt.ac.cti.sut.aperturecoverage.test6;

import java.util.ArrayList;
import java.util.List;

public class Test {
	
	private A a;
	private List<B> b = new ArrayList<>();
	private List<Object> obj;
	
	public void call(A a, B b) {
		this.a = a;
		this.b.add(b);
	}
	
	
}


class Client {
	public static void main() {
		
		var i1 = new Test();
		
		i1.call(new A1(), new B1());
		
	}
}

